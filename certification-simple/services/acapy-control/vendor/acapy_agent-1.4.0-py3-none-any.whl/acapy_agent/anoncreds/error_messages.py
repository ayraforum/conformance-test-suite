"""Error messages for anoncreds."""

ANONCREDS_PROFILE_REQUIRED_MSG = (
    "AnonCreds interface requires AskarAnonCreds or KanonAnonCreds profile"
)
