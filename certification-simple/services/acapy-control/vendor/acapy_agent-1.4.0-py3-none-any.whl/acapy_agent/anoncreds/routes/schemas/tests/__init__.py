"""Tests for AnonCreds schema routes."""
