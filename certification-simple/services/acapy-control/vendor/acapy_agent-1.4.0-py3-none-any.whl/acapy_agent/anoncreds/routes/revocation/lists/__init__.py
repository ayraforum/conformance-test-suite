"""AnonCreds revocation list routes."""
