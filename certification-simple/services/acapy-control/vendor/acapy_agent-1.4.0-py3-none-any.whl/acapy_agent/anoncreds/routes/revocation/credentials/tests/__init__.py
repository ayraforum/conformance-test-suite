"""Tests for AnonCreds credential revocation routes."""
