"""AnonCreds credential definition routes."""
