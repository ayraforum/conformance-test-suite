"""Backend registration module for database backends."""
